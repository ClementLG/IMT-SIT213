# IMT-SIT213
Projet SIT213 IMT Atlantique

A chaque étape:

- Objectifs/Cahier des charges
- Implémentation (description+justification des choix)
- Illustration (cas d'usage, sondes, etc.)
- Performances (courbes+analyse/interprétation)


OK