public class ArgumentsException extends Exception {

    private static final long serialVersionUID = 1789L;

    public ArgumentsException(String s) {
        super(s);
    }
}
