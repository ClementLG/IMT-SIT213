#
# LE GRUIEC Clément
# LE DUC Elouan
# TP0 - SIT213
# 09-2020
#

Fichiers contenus dans l'archive:

bin/
  HelloWorld.class --> code compilé
erreurs.log   --> Redirection des erreurs de compilations (script hello)   
runTests --> script permettant d'effectué différents tests sur le code
cleanAll --> nettoie le dépot (enlève tous les fichiers parasites + la compilation et la javadocs)
genDeliverable --> génère une archive
maCommande --> inutile                
src/
  HelloWorld.java --> code source
compile --> script qui compile code   
genDoc --> script qui génère la javadoc          
readMe.txt --> ce fichier
docs/ --> dossier contenant la javadoc     
hello --> permet d'éxécuter le programme (ex: hello "les amis de l'imt")         
ReponsesTP.txt  --> réponses au questions posées

